# Claude Code Hooks for Project Planning Skills

Add these hooks to your Claude Code settings to automate common tasks.

## How to Add Hooks

Add to your `~/.claude/settings.json` or project's `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hook": "~/.claude/hooks/validate-file-length.sh"
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hook": "~/.claude/hooks/post-generation.sh"
      }
    ]
  }
}
```

---

## Hook Scripts

### 1. validate-file-length.sh

Checks if created/edited files exceed the 150-line limit.

```bash
#!/bin/bash
# ~/.claude/hooks/validate-file-length.sh
# Validates file length after Write/Edit operations

MAX_LINES=150
FILE_PATH="$CLAUDE_TOOL_ARG_FILE_PATH"

# Skip non-code files
if [[ "$FILE_PATH" == *.md ]] || [[ "$FILE_PATH" == *.json ]] || [[ "$FILE_PATH" == *.yaml ]]; then
    exit 0
fi

# Skip if file doesn't exist
if [[ ! -f "$FILE_PATH" ]]; then
    exit 0
fi

LINE_COUNT=$(wc -l < "$FILE_PATH")

if [[ $LINE_COUNT -gt $MAX_LINES ]]; then
    echo "⚠️  WARNING: $FILE_PATH has $LINE_COUNT lines (limit: $MAX_LINES)"
    echo "   Consider refactoring into smaller modules."
fi
```

### 2. post-generation.sh

Runs after Claude stops - useful for auto-committing generated docs.

```bash
#!/bin/bash
# ~/.claude/hooks/post-generation.sh
# Auto-commit docs after generation (optional)

DOCS_DIR="docs"

# Check if docs directory exists and has changes
if [[ -d "$DOCS_DIR" ]]; then
    cd "$(git rev-parse --show-toplevel 2>/dev/null)" || exit 0
    
    # Check for uncommitted changes in docs/
    if git status --porcelain "$DOCS_DIR" | grep -q .; then
        echo ""
        echo "📝 Documentation changes detected in $DOCS_DIR/"
        echo "   Run: git add docs/ && git commit -m 'docs: Update project documentation'"
    fi
fi
```

### 3. check-secrets.sh

Scans for accidentally committed secrets.

```bash
#!/bin/bash
# ~/.claude/hooks/check-secrets.sh
# Checks for potential secrets in files

FILE_PATH="$CLAUDE_TOOL_ARG_FILE_PATH"

if [[ ! -f "$FILE_PATH" ]]; then
    exit 0
fi

# Patterns that might indicate secrets
PATTERNS=(
    "api_key\s*="
    "API_KEY\s*="
    "secret\s*="
    "password\s*="
    "token\s*="
    "sk-[a-zA-Z0-9]"
    "pk-[a-zA-Z0-9]"
)

for pattern in "${PATTERNS[@]}"; do
    if grep -qiE "$pattern" "$FILE_PATH" 2>/dev/null; then
        echo "🔐 WARNING: Potential secret detected in $FILE_PATH"
        echo "   Pattern matched: $pattern"
        echo "   Please use environment variables instead."
    fi
done
```

---

## Installation

```bash
# Create hooks directory
mkdir -p ~/.claude/hooks

# Create hook scripts
cat > ~/.claude/hooks/validate-file-length.sh << 'EOF'
#!/bin/bash
MAX_LINES=150
FILE_PATH="$CLAUDE_TOOL_ARG_FILE_PATH"
if [[ "$FILE_PATH" == *.md ]] || [[ "$FILE_PATH" == *.json ]] || [[ "$FILE_PATH" == *.yaml ]]; then
    exit 0
fi
if [[ ! -f "$FILE_PATH" ]]; then
    exit 0
fi
LINE_COUNT=$(wc -l < "$FILE_PATH")
if [[ $LINE_COUNT -gt $MAX_LINES ]]; then
    echo "⚠️  WARNING: $FILE_PATH has $LINE_COUNT lines (limit: $MAX_LINES)"
fi
EOF

cat > ~/.claude/hooks/check-secrets.sh << 'EOF'
#!/bin/bash
FILE_PATH="$CLAUDE_TOOL_ARG_FILE_PATH"
if [[ ! -f "$FILE_PATH" ]]; then exit 0; fi
if grep -qiE "(api_key|secret|password|token)\s*=" "$FILE_PATH" 2>/dev/null; then
    echo "🔐 WARNING: Potential secret in $FILE_PATH - use env variables"
fi
EOF

# Make executable
chmod +x ~/.claude/hooks/*.sh

# Add to settings
# Edit ~/.claude/settings.json to include the hooks configuration above
```

---

## Quick Settings.json Template

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write",
        "hook": "~/.claude/hooks/validate-file-length.sh"
      },
      {
        "matcher": "Write",
        "hook": "~/.claude/hooks/check-secrets.sh"
      }
    ]
  },
  "permissions": {
    "allow": [
      "Bash(npm:*)",
      "Bash(pip:*)",
      "Bash(git:*)",
      "Bash(mkdir:*)",
      "Write(docs/*)",
      "Write(src/*)",
      "Write(tests/*)"
    ]
  }
}
```
