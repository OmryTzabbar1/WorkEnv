# Claude Code Skills Setup Instructions

Copy and paste this entire prompt to Claude Code to set up your project planning skills.

---

## PROMPT TO GIVE CLAUDE CODE:

```
I need you to set up two Claude Code skills for project planning. Create the following folder structure and files in my personal skills directory (~/.claude/skills/).

## Structure to Create:

~/.claude/skills/
├── project-discovery/
│   ├── SKILL.md
│   └── PROJECT-BRIEF-TEMPLATE.md
└── project-docs-generator/
    ├── SKILL.md
    └── guidelines/
        ├── _base.md
        ├── academic-msc.md
        └── lean-startup.md

## File Contents:

### 1. ~/.claude/skills/project-discovery/SKILL.md

---
name: project-discovery
description: Guides users through a 9-phase interview to clarify project ideas and produce a structured Project Brief. Use when starting a new project, when requirements are unclear, or when the user says they have a project idea but needs help defining it.
---

# Project Discovery Agent

Transforms vague project ideas into well-defined, actionable Project Briefs through guided conversation.

## When to Use This Skill

- User says "I want to build..." but details are vague
- User needs help clarifying requirements before coding
- User wants to plan a project properly
- User mentions needing a PRD or project documentation

## Interview Flow

Conduct interviews in **9 phases**. Ask 2-4 questions per response, wait for answers, then continue.

---

## Phase 1: Project Purpose & Vision

**Goal**: Understand the fundamental "why" behind the project.

Ask:
1. **Why are you making this project?** What problem or frustration sparked this idea?
2. **Who is this project for?** Describe your ideal user and their current pain point.
3. **What makes this valuable?** Why would someone choose this over alternatives?

**Dig deeper if**: Answers are generic ("to help people"), audience is "everyone", or value sounds like features not benefits.

---

## Phase 2: Core Functionality & Features

**Goal**: Define what users must be able to do.

Ask:
1. Walk me through a typical user session from start to finish
2. If you could only ship 3 features, which would they be?
3. What should users NOT be able to do? (guardrails)
4. What happens when something goes wrong?

**Important**: Do NOT discuss tech stack yet. Focus purely on user actions.

---

## Phase 3: Data & Information Architecture

**Goal**: Understand what data exists and how it relates.

Ask:
1. What information does your project need to work with?
2. What are the main "things" (entities) in your project?
3. How do these things relate to each other?
4. What data is sensitive or requires special handling?

**Exercise**: Ask user to describe data as boxes and arrows on a whiteboard.

---

## Phase 4: MVP Definition

**Goal**: Strip the project down to its absolute minimum viable version.

Ask:
1. Looking at everything we discussed, what's the ONE core workflow?
2. What can you remove and still have something useful?
3. What's the quickest way to validate the core assumption?
4. What single metric would tell you the MVP works?

---

## Phase 5: User Experience & Wireframing

**Goal**: Think through the user journey (UX over UI).

Ask:
1. Describe the user's first 60 seconds with your project
2. What are the key screens or states?
3. Where might users get confused or stuck?
4. What feedback does the user need at each step?

**Encourage**: "Even rough sketches help - describe what you're imagining"

---

## Phase 6: Project Scope & Timeline

**Goal**: Understand project lifespan and engineering investment.

Ask:
1. What's the intended lifespan? (days, weeks, months)
2. Do you plan to add more features after MVP?
3. Will other people work on this codebase?
4. What's your maintenance expectation?

**Categorize**:
- Quick Script (days): Minimal structure
- Small Project (1-2 weeks): Basic organization
- Medium Project (weeks-months): Proper architecture
- Long-term Product (months+): Extensive documentation, CI/CD

---

## Phase 7: Delivery Platform

**Goal**: Determine how users will access the project.

Ask:
1. How will users access this? (web, mobile, CLI, extension, API)
2. What devices and contexts will users be in?
3. Are there integration requirements with other tools?
4. What are the performance expectations?

---

## Phase 8: Technology Stack

**Goal**: Choose appropriate technologies based on all previous decisions.

Ask:
1. Do you have existing tech preferences or constraints?
2. What are your deployment constraints? Where will this be hosted?
3. Are there integration requirements that dictate technology?
4. Have you deployed this stack before?

**Principle**: Best tool for the project, not the other way around.

---

## Phase 9: Development Process

**Goal**: Establish the development workflow.

Ask:
1. How will you organize the codebase? (folder structure, naming)
2. What's your development environment?
3. How will you handle version control?
4. What's your testing approach?
5. What about CI/CD?

---

## Handling Unclear Responses

Use these techniques:
- **Restate**: "So if I understand correctly, you're saying [X]. Is that right?"
- **Ask for examples**: "Can you give me a specific example?"
- **Offer options**: "Do you mean A, B, or something else?"
- **Challenge**: "You mentioned [X] - have you considered [alternative]?"

---

## Output: Project Brief

After completing all phases, generate a Project Brief. See [PROJECT-BRIEF-TEMPLATE.md](PROJECT-BRIEF-TEMPLATE.md) for the full template.

The brief includes:
1. Executive Summary
2. Vision & Purpose
3. Core Functionality (P0/P1/P2 features)
4. Data Architecture
5. MVP Specification
6. User Experience
7. Project Scope
8. Platform & Delivery
9. Technology Recommendations
10. Development Process
11. Open Questions & Risks

---

## Handoff

After generating the Project Brief, inform the user:

"Your Project Brief is ready! You can now use the **project-docs-generator** skill to create your full documentation set (PRD.md, CLAUDE.md, PLANNING.md, TASKS.md)."


### 2. ~/.claude/skills/project-discovery/PROJECT-BRIEF-TEMPLATE.md

# Project Brief Template

Use this template to generate the final Project Brief after completing all 9 interview phases.

---

# Project Brief: [Project Name]

Generated: [Date]

---

## Executive Summary

[2-3 sentence overview capturing the essence of the project]

---

## 1. Vision & Purpose

### Problem Statement
[Clear description of the problem being solved]

### Target Users
[Detailed user persona(s)]

### Value Proposition
[Core value in one sentence]

### Success Criteria
[How we'll know this project succeeded]

---

## 2. Core Functionality

### Must-Have Features (P0)
| Feature | User Story | Acceptance Criteria |
|---------|------------|---------------------|
| [Name] | As a [user], I want [action] so that [benefit] | [Testable criteria] |

### Should-Have Features (P1)
| Feature | User Story | Acceptance Criteria |
|---------|------------|---------------------|
| [Name] | [User story] | [Criteria] |

### Nice-to-Have Features (P2)
| Feature | User Story | Notes |
|---------|------------|-------|
| [Name] | [User story] | [Why deferred] |

### Guardrails & Constraints
- [What users cannot/should not do]
- [Safety/privacy/compliance requirements]

---

## 3. Data Architecture

### Core Entities
| Entity | Description | Key Attributes |
|--------|-------------|----------------|
| [Name] | [What it represents] | [Main fields] |

### Relationships
```
[Entity A] ---(relationship)---> [Entity B]
```

### Data Sensitivity
- [PII considerations]
- [Security requirements]

---

## 4. MVP Specification

### Core Workflow
[Step-by-step description of the one essential user journey]

### MVP Feature Set
- [ ] [Feature 1 - essential]
- [ ] [Feature 2 - essential]
- [ ] [Feature 3 - essential]

### Explicitly Excluded from MVP
- [Feature X - reason]

### MVP Success Metric
[Single metric that validates the MVP]

---

## 5. User Experience

### User Journey Map
1. [Entry point] → [User sees...]
2. [Action 1] → [System responds...]
3. [Completion] → [User achieves...]

### Key Screens/States
| Screen | Purpose | Key Elements |
|--------|---------|--------------|
| [Name] | [What user does here] | [Main components] |

### UX Priorities
1. [Most important consideration]
2. [Second priority]
3. [Third priority]

---

## 6. Project Scope

### Timeline
- **Type**: [Quick Script / Small Project / Medium Project / Long-term Product]
- **Estimated Duration**: [Time range]

### Future Roadmap
| Phase | Features | Timing |
|-------|----------|--------|
| MVP | [Features] | [When] |
| v1.1 | [Features] | [When] |
| v2.0 | [Features] | [When] |

---

## 7. Platform & Delivery

### Primary Platform
[Web / Mobile / Desktop / CLI / Extension / API]

### Requirements
- [Device/browser support]
- [Offline requirements]
- [Performance expectations]

### Integrations
| System | Purpose | Priority |
|--------|---------|----------|
| [Name] | [Why needed] | [P0/P1/P2] |

---

## 8. Technology Recommendations

### Recommended Stack
| Layer | Technology | Rationale |
|-------|------------|-----------|
| Frontend | [Tech] | [Why] |
| Backend | [Tech] | [Why] |
| Database | [Tech] | [Why] |
| Hosting | [Platform] | [Why] |

### Deployment Strategy
[How the project will be deployed]

---

## 9. Development Process

### Repository Structure
```
project-root/
├── [folder structure]
```

### Conventions
- **File naming**: [Convention]
- **Commit messages**: [Format]

### Quality Assurance
- **Testing**: [Approach]
- **CI/CD**: [Pipeline or "Not needed"]

---

## 10. Open Questions & Risks

### Unresolved Questions
- [ ] [Question needing research]

### Identified Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| [Risk] | [H/M/L] | [Strategy] |

### Assumptions
- [Assumption 1]
- [Assumption 2]

---

## Ready for Documentation Generation

This Project Brief can be passed to the **project-docs-generator** skill to create:
- PRD.md
- CLAUDE.md  
- PLANNING.md
- TASKS.md


### 3. ~/.claude/skills/project-docs-generator/SKILL.md

---
name: project-docs-generator
description: Generates project documentation (PRD.md, CLAUDE.md, PLANNING.md, TASKS.md) based on a Project Brief and selected guideline. Use when the user has a defined project and needs documentation, or after completing project-discovery.
---

# Project Documentation Generator

Generates comprehensive project documentation based on a Project Brief and selected quality guideline.

## When to Use This Skill

- User has a Project Brief (from project-discovery or manually created)
- User asks for PRD, project docs, or documentation
- User wants to set up a new project with proper structure
- After completing the project-discovery interview

## Available Guidelines

| Guideline | Use When | Level |
|-----------|----------|-------|
| `academic-msc` | M.Sc. submissions, formal projects | Comprehensive (10 sections) |
| `lean-startup` | MVPs, hackathons, prototypes | Minimal |

See [guidelines/](guidelines/) for full details on each.

## Submission Requirements Coverage (academic-msc)

The academic guideline covers 10 requirement categories:

1. **Project Documents and Planning** → PRD.md, PLANNING.md
2. **Code Documentation and Project Structure** → CLAUDE.md
3. **Configuration Management and Security** → CLAUDE.md
4. **Testing and Software Quality** → CLAUDE.md, TASKS.md
5. **Research and Results Analysis** → PLANNING.md, TASKS.md
6. **User Interface and User Experience** → PRD.md, PLANNING.md
7. **Version Management and Development Documentation** → CLAUDE.md
8. **Costs and Pricing** → PLANNING.md (if using APIs)
9. **Extensibility and Maintainability** → PLANNING.md, CLAUDE.md
10. **International Quality Standards (ISO/IEC 25010)** → All documents

---

## Execution Flow

### Step 1: Determine Guideline

**If user specifies a guideline:**
- "Use academic standards" → `academic-msc`
- "Keep it lean" / "MVP docs" → `lean-startup`

**If not specified**, ask:
> "What type of project is this?
> - **Academic/formal** → comprehensive documentation
> - **MVP/prototype** → minimal documentation"

**Default**: `academic-msc` (better to over-document)

### Step 2: Load Guideline

1. Read [guidelines/_base.md](guidelines/_base.md) (always)
2. Read selected guideline (e.g., [guidelines/academic-msc.md](guidelines/academic-msc.md))
3. Apply guideline requirements to generation

### Step 3: Validate Input

Check that Project Brief contains:
- [ ] Project name
- [ ] Problem statement
- [ ] Target users  
- [ ] Core features (at least 3)
- [ ] Success metric

**If missing**: Ask for the missing information before generating.

### Step 4: Generate Documents

Generate in order:
1. **PRD.md** — Defines WHAT we're building
2. **PLANNING.md** — Defines HOW we'll build it
3. **CLAUDE.md** — Defines development RULES
4. **TASKS.md** — Defines the WORK breakdown

### Step 5: Save & Report

1. Create `docs/` directory
2. Save all four files
3. Report what was generated and any sections needing review

---

## Document Responsibilities

Each generated document covers specific submission requirements:

### PRD.md
**Covers:** Section 1 (Project Documents), Section 6 (UI/UX requirements)
- Project overview and problem statement
- Target audience and stakeholders
- Functional requirements with user stories
- Use cases with full flows
- Non-functional requirements
- Timeline and milestones
- Success metrics and KPIs

### PLANNING.md
**Covers:** Section 1 (Architecture), Section 5 (Research), Section 8 (Costs), Section 9 (Extensibility)
- C4 diagrams (Context, Container, Component)
- Architectural Decision Records (ADRs)
- API documentation
- Tech stack decisions with rationale
- Research methodology (if applicable)
- Cost analysis tables (if using APIs)
- Extension points and plugin architecture

### CLAUDE.md
**Covers:** Section 2 (Code/Structure), Section 3 (Config/Security), Section 4 (Testing), Section 7 (Version Management)
- Project structure (150-line file limit)
- Naming conventions
- Code quality standards
- Configuration management rules
- Security practices
- Testing requirements (70%+ coverage)
- Git workflow (10-20+ commits)
- Prompt engineering log structure

### TASKS.md
**Covers:** Section 4 (Testing tasks), Section 5 (Research tasks), Section 10 (ISO checklist)
- Phase-based task breakdown
- Testing tasks and coverage goals
- Research experiment tasks
- ISO/IEC 25010 compliance checklist
- Progress tracking

---

## Guideline-Specific Rules

### academic-msc (10 Submission Requirement Sections)

**PRD.md must include:**
- All sections from guideline 1.1
- Stakeholders table with roles and interests
- KPI table with measurement methods
- Detailed use cases (Actor, Preconditions, Flow, Postconditions)
- Non-functional requirements (performance, security, scalability)
- Out-of-scope section (explicit exclusions)
- Timeline with milestone deliverables

**PLANNING.md must include:**
- C4 diagrams: Context (mandatory), Container (mandatory), Component (if complex)
- Minimum 2-3 ADRs with: Status, Context, Decision, Consequences, Trade-offs
- API documentation with data schemas (if applicable)
- Deployment diagram
- Cost analysis table (if using APIs)
- Extension points documentation

**CLAUDE.md must include:**
- **150-line file limit** (strictly enforced)
- Full project structure template with `prompts/` directory
- Naming conventions table
- Docstring requirements
- Configuration separation rules
- Security practices (no API keys in code)
- Git commit format: `<type>(<scope>): <description> [TaskID]`
- 10-20+ commits required
- 70-80% test coverage target

**TASKS.md must include:**
- 5-phase structure:
  1. Project Setup & Infrastructure
  2. Core Development  
  3. Testing & Quality Assurance
  4. Research & Analysis (if applicable)
  5. Final Documentation & Polish
- Task format: `| ID | Task | Priority | Status | Notes |`
- ISO/IEC 25010 submission checklist (all 10 sections)
- Daily progress log template
- Blockers tracking

### lean-startup

**PRD.md:**
- One page maximum
- 5 sections only (Problem, Solution, User, Features, Metric)

**PLANNING.md:**
- One diagram (ASCII OK)
- Tech decisions as bullets
- No ADRs required

**CLAUDE.md:**
- 4 sections max
- No strict file limits

**TASKS.md:**
- Now/Next/Later format
- Simple checkboxes

---

## Output Format

After generation, provide:

## Documentation Generated ✓

**Guideline used:** [guideline name]

### Files Created
- `docs/PRD.md`
- `docs/PLANNING.md`
- `docs/CLAUDE.md`
- `docs/TASKS.md`

### Sections Needing Review
- [Section]: [Why it needs human review]

### Assumptions Made
- [Assumption 1]
- [Assumption 2]

---

## Error Handling

**If Project Brief is too vague**:
```
I need more information before generating documentation.

Missing:
- [What's missing]

Would you like to run project-discovery first?
```

**If guideline doesn't fit**:
```
The [guideline] doesn't seem right for this project.

Consider:
- [alternative]: better for [reason]
```


### 4. ~/.claude/skills/project-docs-generator/guidelines/_base.md

# Base Guideline

Universal requirements that all guidelines extend.

---

## Meta

```yaml
id: _base
version: 1.0
```

---

## Universal Requirements

### File Standards
- Markdown format, UTF-8 encoding
- Maximum line length: 120 characters

### Output Location
- All documents go to `docs/` directory
- Files: `PRD.md`, `CLAUDE.md`, `PLANNING.md`, `TASKS.md`

---

## Minimum Required Sections

### PRD.md
- [ ] Project name and version
- [ ] Problem statement
- [ ] Target users
- [ ] Feature list with priorities
- [ ] Success criteria

### CLAUDE.md
- [ ] Project overview
- [ ] Code organization rules
- [ ] Naming conventions

### PLANNING.md
- [ ] Architecture overview
- [ ] Technology choices with rationale

### TASKS.md
- [ ] Task breakdown
- [ ] Priority indicators
- [ ] Status tracking

---

## Validation

### Before Generation
- Project Brief must include: purpose, users, features

### After Generation
- All required sections present
- No placeholder text (`[TBD]`, `[TODO]`)
- Cross-references valid


### 5. ~/.claude/skills/project-docs-generator/guidelines/academic-msc.md

---
name: academic-msc-guideline
description: Complete submission requirements for M.Sc. Computer Science software projects. Based on Dr. Segal Yoram's guidelines with ISO/IEC 25010 compliance.
version: 2.0
---

# Academic M.Sc. Submission Guideline

Complete requirements for software project submissions at academic excellence level.

---

## Overview

This guideline ensures projects meet all submission criteria for M.Sc. Computer Science. Projects are evaluated on:
- Comprehensive documentation
- High-quality development
- Research capability demonstration
- Professional presentation

**Important Note**: Not every section is mandatory, but the more criteria met, the higher the quality evaluation and grade.

---

## 1. Project Documents and Planning

### 1.1 Product Requirements Document (PRD.md)

The central document defining project purpose and requirements.

**Required Sections:**

| Section | Contents |
|---------|----------|
| Project Overview | Context, background, problem statement |
| Problem Statement | Clear description of user problem being solved |
| Market Analysis | Competitive landscape, strategic positioning |
| Target Audience | Stakeholders table with roles and interests |
| Project Goals | Measurable objectives with KPIs |
| Acceptance Criteria | How to evaluate if project meets requirements |
| Functional Requirements | Prioritized feature list (P0/P1/P2) with user stories |
| Use Cases | Actor, preconditions, main flow, postconditions, alternatives |
| Non-Functional Requirements | Performance, security, availability, scalability |
| Assumptions | What is assumed to be true |
| Dependencies | External systems table (dependency, type, risk level) |
| Constraints | Technical and organizational limitations |
| Out-of-Scope | Explicitly excluded items |
| Timeline & Milestones | Schedule table with deliverables per phase |
| Checkpoint Reviews | Review dates and criteria |

**Format Requirements:**
- Stakeholders as table: `| Stakeholder | Role | Interest |`
- KPIs as table: `| KPI | Target | Measurement Method |`
- Features prioritized: P0 (Must), P1 (Should), P2 (Nice-to-have)
- Use cases with full flow documentation

### 1.2 Architecture Document (PLANNING.md)

Comprehensive technical description of system structure and operation.

**Required Diagrams:**

| Diagram Type | Purpose | Required Level |
|--------------|---------|----------------|
| C4 Context | System and external actors | Mandatory |
| C4 Container | Major components/services | Mandatory |
| C4 Component | Internal component structure | For complex systems |
| UML Sequence | Complex process interactions | As needed |
| UML Class | Object relationships | For OOP projects |
| Deployment | Infrastructure and operations | Mandatory |

**Architectural Decision Records (ADRs):**

Minimum 2-3 ADRs documenting major decisions:

```markdown
## ADR-001: [Decision Title]

**Status:** Accepted | Superseded | Deprecated

**Context:** 
[What situation requires a decision]

**Decision:**
[What was decided]

**Consequences:**
[Positive and negative outcomes]

**Alternatives Considered:**
[Other options and why rejected]

**Trade-offs:**
[What was gained vs. sacrificed]
```

**API Documentation (if applicable):**
- Complete endpoint documentation
- Data schemas for all entities
- Contracts between system components
- Request/response examples

---

## 2. Code Documentation and Project Structure

### 2.1 README File (Comprehensive)

Must serve as complete user manual.

**Required Sections:**

| Section | Contents |
|---------|----------|
| Installation Instructions | System requirements, step-by-step setup, all platforms |
| Environment Setup | How to configure environment variables |
| Troubleshooting | Common issues and solutions |
| Usage Instructions | How to run in different modes (CLI flags, GUI) |
| Examples & Demonstrations | Working code examples, screenshots, demo videos |
| Configuration Guide | All configurable parameters explained |
| Contribution Guidelines | Code standards, PR process |
| License & Credits | License file, third-party attribution |

### 2.2 Modular Project Structure

**Required Structure:**

```
project-root/
├── src/                    # Source code
│   ├── agents/             # Agent modules (if applicable)
│   ├── core/               # Core business logic
│   ├── utils/              # Helper functions
│   └── config/             # Configuration code
├── tests/                  # Unit and integration tests
├── data/                   # Databases and input files
├── results/                # Experiment results
├── docs/                   # Additional documentation
├── config/                 # Configuration files
├── assets/                 # Images, graphs, resources
├── notebooks/              # Analysis notebooks (Jupyter)
├── prompts/                # Prompt engineering log
│   ├── README.md           # Overview and lessons learned
│   ├── architecture/       # Architecture prompts
│   ├── code-generation/    # Code generation prompts
│   ├── testing/            # Testing prompts
│   └── documentation/      # Documentation prompts
├── README.md
├── requirements.txt        # or package.json
├── .env.example
└── .gitignore
```

**File Size Limit:**
- **Maximum 150 lines per file** (strictly enforced)
- When file exceeds limit, refactor into smaller modules
- Each file should have single responsibility (separation of concerns)

**Naming Conventions:**
- Files: `snake_case.py` (Python), `kebab-case.ts` (TypeScript)
- Classes: `PascalCase`
- Functions: `snake_case` (Python), `camelCase` (JS/TS)
- Constants: `UPPER_SNAKE_CASE`

### 2.3 Code Quality and Comments

**Comment Standards:**
- Comments explain "WHY" not "WHAT"
- Every function, class, and module needs docstrings

**Docstring Requirements:**
```python
def function_name(param1: type, param2: type) -> return_type:
    """
    Brief description of function purpose.
    
    Args:
        param1: Description of parameter
        param2: Description of parameter
        
    Returns:
        Description of return value
        
    Raises:
        ExceptionType: When this occurs
    """
```

---

## 3. Configuration Management and Information Security

### 3.1 Configuration Files

**Separation Principle:**
- Configuration MUST be separated from code
- Use standard formats: `.json`, `.yaml`, `.env`
- No hardcoded values in source code

**Required Files:**
- `.env.example` - Template with safe defaults
- `.gitignore` - Must exclude sensitive config files

### 3.2 Information Security

**Critical Rule: No API keys or secrets in source code**

**Required Practices:**
- Use environment variables: `os.environ.get("API_KEY")`
- Hide `.env` files via `.gitignore`
- Provide `.env.example` without real values

---

## 4. Testing and Software Quality

### 4.1 Unit Tests

**Coverage Requirements:**
- **Minimum 70-80% coverage** for new code
- Enhanced coverage for critical business logic
- Must cover both normal paths AND edge cases

**Required Tools:**
- Standard frameworks: `pytest`, `unittest`, `jest`
- CI/CD pipeline integration
- Automated coverage reports

### 4.2 Handling Edge Cases and Failures

**Error Handling Requirements:**
- Defensive programming with input validation
- Clear, user-friendly error messages
- Detailed logging for debugging
- Graceful degradation when failures occur

### 4.3 Expected Test Results

- Document expected output for each test
- Generate automated reports with pass/fail rates
- Preserve logs of successful and failed runs

---

## 5. Research and Results Analysis

### 5.1 Parameter Investigation

**Sensitivity Analysis Process:**
1. Systematic experiments with controlled parameter changes
2. Accurate documentation of each parameter's effect
3. Identify critical parameters affecting performance

### 5.2 Results Analysis Notebook

**Required Tool:** Jupyter Notebook or equivalent

**Must Include:**
- Code + text + results combined
- Comparison between different algorithms/configurations
- Statistical analysis with confidence intervals
- LaTeX formulas for mathematical expressions

### 5.3 Visual Presentation of Results

**Chart Types:** Bar, Line, Heatmaps, Scatter, Box, Waterfall

**Quality Requirements:**
- Clear labels, consistent colors
- Detailed captions and legends
- High resolution (publication quality)

---

## 6. User Interface and User Experience

### 6.1 Quality Criteria (Usability)

**Nielsen's 10 Heuristics (Apply All):**
1. Visibility of system status
2. Match between system and real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition over recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize and recover from errors
10. Help and documentation

### 6.2 Interface Documentation

- Screenshots of every screen/state
- Typical user workflow from start to goal
- Accessibility considerations

---

## 7. Version Management and Development Documentation

### 7.1 Best Practices with Git

**Commit Requirements:**
- **Minimum 10-20 commits** showing clear progression
- Format: `<type>(<scope>): <description>`
- Reference task IDs: `feat(auth): Add login flow [P2.1.3]`

**Commit Types:** feat, fix, docs, refactor, test, chore

### 7.2 The Prompt Book (Prompt Engineering Log)

**Directory Structure:**
```
prompts/
├── README.md              # Overview and lessons learned
├── architecture/          # System design prompts
├── code-generation/       # Code creation prompts
├── testing/               # Test generation prompts
└── documentation/         # Doc generation prompts
```

---

## 8. Costs and Pricing

### 8.1 Cost Analysis (If Using APIs)

**Token Usage Table:**

| Model | Input Tokens | Output Tokens | Total Cost |
|-------|--------------|---------------|------------|
| [Model] | [Count] | [Count] | $[Amount] |

### 8.2 Budget Management

- Batch processing for efficiency
- Model selection by cost-effectiveness
- Real-time usage tracking

---

## 9. Extensibility and Maintainability

### 9.1 Extension Points

- Enable adding functionality without core code changes
- Define clear interfaces between core and plugins
- API-first design with middleware support

### 9.2 Maintainability

| Characteristic | Description |
|----------------|-------------|
| Modularity | Independent components |
| Separation of Concerns | Each part handles one thing |
| Reusability | Write once, use many places |
| Analyzability | Easy to understand and debug |
| Testability | Easy to write automated tests |

---

## 10. International Quality Standards

### 10.1 Product Quality Characteristics (ISO/IEC 25010)

| Characteristic | Sub-characteristics | Requirement |
|----------------|---------------------|-------------|
| **Functional Suitability** | Completeness, Correctness, Appropriateness | Mandatory |
| **Performance Efficiency** | Time behavior, Resource utilization, Capacity | Mandatory |
| **Compatibility** | Interoperability, Coexistence | If applicable |
| **Usability** | Learnability, Operability, Error protection, Aesthetics, Accessibility | Mandatory |
| **Reliability** | Maturity, Availability, Fault tolerance, Recoverability | Mandatory |
| **Security** | Confidentiality, Integrity, Authenticity, Accountability | Mandatory |
| **Maintainability** | Modularity, Reusability, Analyzability, Modifiability, Testability | Mandatory |
| **Portability** | Adaptability, Installability, Replaceability | Recommended |

---

## Final Submission Checklist

### 1. Project Documents and Planning
- [ ] PRD.md with all sections
- [ ] Architecture documentation with C4 diagrams
- [ ] ADRs (minimum 2-3)

### 2. Code Documentation and Structure
- [ ] README.md at user manual level
- [ ] No file exceeds 150 lines
- [ ] Docstrings for all functions/classes

### 3. Configuration and Security
- [ ] Configuration separated from code
- [ ] No API keys in source code
- [ ] `.gitignore` configured

### 4. Testing and Quality
- [ ] 70%+ unit test coverage
- [ ] Edge cases documented
- [ ] Automated test reports

### 5. Research (if applicable)
- [ ] Parameter sensitivity analysis
- [ ] Analysis notebook
- [ ] Publication-quality graphs

### 6. UI/UX
- [ ] Screenshots of all screens
- [ ] Nielsen's heuristics applied

### 7. Version Management
- [ ] 10-20+ meaningful commits
- [ ] Prompt engineering log

### 8. Costs (if using APIs)
- [ ] Token usage table
- [ ] Optimization strategies

### 9. Extensibility
- [ ] Extension points documented

### 10. Quality Standards
- [ ] ISO/IEC 25010 addressed


### 6. ~/.claude/skills/project-docs-generator/guidelines/lean-startup.md

---
name: lean-startup-guideline
description: Minimal documentation for rapid MVP development. Use for quick prototypes, hackathons, or validation projects.
version: 1.0
---

# Lean Startup Guideline

Minimal documentation for rapid MVP development.

---

## Overview

For:
- Quick MVPs (days to 2 weeks)
- Solo developers
- Hackathons and prototypes
- Validation-focused projects

**Philosophy**: Documentation helps you build faster, not slow you down.

---

## PRD.md Requirements

**One page maximum.** Five sections only:

```markdown
# [Project Name] - PRD

## Problem
[2-3 sentences - what pain point?]

## Solution  
[2-3 sentences - how does it solve it?]

## Target User
[1 sentence - who specifically?]

## Core Features
- [Feature 1]
- [Feature 2]
- [Feature 3]

## Success Metric
[1 metric - how will you know it works?]
```

---

## CLAUDE.md Requirements

**Four sections maximum:**

```markdown
# CLAUDE.md

## Overview
[3 sentences max]

## How to Run
[Commands only]

## Key Constraints
[Hard rules if any]

## Code Style
[Use linter defaults]
```

---

## PLANNING.md Requirements

**One diagram maximum.** ASCII art is fine:

```
┌──────┐     ┌─────────┐     ┌─────────┐
│ User │────▶│ Your App│────▶│ API     │
└──────┘     └─────────┘     └─────────┘
```

**Tech decisions as bullets:**
- Frontend: [Tech] (reason)
- Backend: [Tech] (reason)
- Database: [Tech] (reason)
- Hosting: [Tech] (reason)

No ADRs required.

---

## TASKS.md Requirements

**Simple checklist only:**

```markdown
# Tasks

## Now
- [ ] [Task 1]
- [ ] [Task 2]

## Next
- [ ] [Task 3]
- [ ] [Task 4]

## Later
- [ ] [Task 5]
```

No status emojis. No due dates.

---

## Testing (Lean Version)

- Test happy path manually
- ONE test for critical function
- If it breaks, you'll know

---

## README (Lean Version)

```markdown
# Project Name

[1-2 sentences]

## Setup
[commands]

## Usage
[screenshot or description]
```

---

## Security

- Use `.env` for secrets
- Don't commit `.env`

---

## Lean Checklist

Before shipping:
- [ ] Core feature works?
- [ ] Someone else can run it?
- [ ] Nothing embarrassingly broken?

Ship it.


---

## Instructions for Claude Code:

1. Create the directory structure exactly as shown
2. Create each file with the content provided above
3. After creating all files, verify by listing the structure
4. Confirm skills are ready by checking `~/.claude/skills/`

Please create all these files now.
```

---

## ALTERNATIVE: If You Want Project-Level Skills (Shared via Git)

Replace `~/.claude/skills/` with `.claude/skills/` in your project directory:

```
Change all paths from:
  ~/.claude/skills/project-discovery/...
  ~/.claude/skills/project-docs-generator/...

To:
  .claude/skills/project-discovery/...
  .claude/skills/project-docs-generator/...
```

Then commit to git to share with your team.
