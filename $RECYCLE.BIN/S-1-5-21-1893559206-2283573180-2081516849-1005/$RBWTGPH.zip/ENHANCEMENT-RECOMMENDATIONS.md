# Environment Enhancement Recommendations

Honest assessment of what to add to your Claude Code project planning environment.

---

## Summary

| Enhancement | Recommendation | Reason |
|-------------|----------------|--------|
| **Hooks** | ✅ Yes | High value, low effort. Auto-validate 150-line limit, check for secrets |
| **MCP (GitHub)** | ⚠️ Maybe | Only if you want auto-create repos/issues from TASKS.md |
| **MCP (Others)** | ❌ Skip | Overkill for doc generation workflow |
| **Slash Commands** | ⚠️ Maybe | Nice shortcuts, but skills already auto-trigger |
| **Output Styles** | ❌ Skip | Default works fine for your use case |
| **More Guidelines** | ✅ Yes | Add `research-paper` if you do ML/research projects |

---

## ✅ Definitely Add: Hooks

**Why**: Automatic enforcement of your submission requirements without thinking about it.

**Recommended Hooks:**

1. **validate-file-length.sh** — Warns when files exceed 150 lines
2. **check-secrets.sh** — Catches accidental API keys before commit
3. **format-check.sh** — Ensures markdown consistency

See [HOOKS-SETUP.md](HOOKS-SETUP.md) for implementation.

---

## ⚠️ Consider: MCP (GitHub Only)

**Only worth it if** you want to automatically:
- Create GitHub repos from project briefs
- Convert TASKS.md into GitHub Issues
- Create project boards

**Skip if** you're fine manually creating repos and managing tasks.

### If You Want GitHub MCP:

```bash
# Install GitHub MCP server
npm install -g @anthropic/mcp-server-github

# Add to Claude Code MCP config (~/.claude/mcp.json)
{
  "servers": {
    "github": {
      "command": "mcp-server-github",
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

**Use case**: After generating TASKS.md, say:
> "Create GitHub issues from TASKS.md"

**My take**: This is a nice-to-have, not essential. Your workflow is primarily about generating docs locally, not automating GitHub. I'd skip this unless you find yourself repeatedly creating the same repo structure.

---

## ❌ Skip: Other MCP Servers

**Why not:**

| MCP Server | Why Skip |
|------------|----------|
| Google Drive | You can just manually upload docs |
| Notion | Adds complexity, your docs are in markdown anyway |
| Slack | Not relevant to doc generation |
| Database MCPs | You're generating docs, not querying data |
| Web Search | Skills already have the knowledge they need |

**General principle**: MCP is powerful for workflows that need real-time external data. Your workflow is about generating documents from structured input — it doesn't need external connections.

---

## ⚠️ Consider: Additional Guidelines

Worth adding if you work on different project types:

### research-ml.md
For ML/AI research projects with emphasis on:
- Experiment tracking (MLflow, W&B)
- Model cards
- Dataset documentation
- Reproducibility requirements
- Benchmark tables

### personal-project.md  
Even lighter than lean-startup:
- Single README only
- No formal PRD
- Just enough to remember what you built

### Want me to create these? Just ask.

---

## ❌ Skip: Output Styles

Output styles customize how Claude responds (tone, formatting, etc.)

**Why skip**: Your skills already define the output format precisely. Adding an output style would just add another layer of configuration that might conflict with skill instructions.

---

## ❌ Skip: Slash Commands

Slash commands are user-triggered (`/command`), while skills are model-triggered (Claude decides when to use them).

**Why skip**: Your skills already auto-trigger when relevant:
- "I want to build X" → triggers project-discovery
- "Generate docs" → triggers project-docs-generator

Slash commands would be redundant. If anything, they'd give you less flexibility because you'd have to remember to type them.

**Exception**: If you want a shortcut to force a specific guideline:

```json
{
  "commands": {
    "/academic": {
      "description": "Generate docs with academic-msc guideline",
      "prompt": "Generate project documentation using the academic-msc guideline for this project."
    },
    "/lean": {
      "description": "Generate docs with lean-startup guideline", 
      "prompt": "Generate minimal project documentation using the lean-startup guideline."
    }
  }
}
```

But honestly, just saying "use academic guidelines" works fine.

---

## What I'd Actually Do

If I were setting up this environment for M.Sc. projects:

### Minimal Setup (Recommended)
```
~/.claude/
├── skills/
│   ├── project-discovery/
│   └── project-docs-generator/
├── hooks/
│   ├── validate-file-length.sh    ← Enforces 150-line limit
│   └── check-secrets.sh           ← Catches API keys
└── settings.json                   ← Hook configuration
```

**That's it.** This gives you:
- Automatic project planning interviews
- Documentation generation with swappable guidelines
- Automatic enforcement of code quality rules
- Security checks

### Extended Setup (Only If Needed)
Add GitHub MCP only if you're tired of manually:
- Creating repos
- Setting up issue templates
- Converting task lists to issues

---

## Final Recommendation

**Start minimal. Add complexity only when you feel friction.**

Your current setup (2 skills + guidelines) covers 95% of what you need. Hooks add the remaining automatic enforcement.

Don't add MCP or other integrations until you've used the basic setup for a few projects and identified specific pain points that automation would solve.

**The best developer environment is the simplest one that gets the job done.**
