# Project Planning Skills for Claude Code

Two complementary skills that transform vague project ideas into comprehensive documentation.

---

## What's Included

```
skills/
├── project-discovery/           # Skill 1: Clarifies your idea
│   ├── SKILL.md                 # Main skill file
│   └── PROJECT-BRIEF-TEMPLATE.md
│
└── project-docs-generator/      # Skill 2: Generates documentation
    ├── SKILL.md                 # Main skill file
    └── guidelines/              # Swappable quality standards
        ├── _base.md
        ├── academic-msc.md      # For M.Sc. submissions
        └── lean-startup.md      # For quick MVPs
```

---

## How They Work Together

```
Your vague idea
      │
      ▼
┌─────────────────────┐
│  project-discovery  │  ← Asks 9 phases of questions
└──────────┬──────────┘
           │
           ▼
    Project Brief
           │
           ▼
┌─────────────────────┐
│project-docs-generator│ ← Applies selected guideline
└──────────┬──────────┘
           │
           ▼
docs/
├── PRD.md
├── PLANNING.md
├── CLAUDE.md
└── TASKS.md
```

---

## Installation

### Option A: Personal Skills (just for you)

```bash
# Create the skills directory
mkdir -p ~/.claude/skills

# Copy both skills
cp -r project-discovery ~/.claude/skills/
cp -r project-docs-generator ~/.claude/skills/
```

### Option B: Project Skills (shared with team)

```bash
# In your project root
mkdir -p .claude/skills

# Copy both skills
cp -r project-discovery .claude/skills/
cp -r project-docs-generator .claude/skills/

# Commit to git
git add .claude/skills/
git commit -m "Add project planning skills"
```

---

## Usage

### Starting a New Project

Just tell Claude you have an idea:

```
I want to build a habit tracking app
```

Claude will automatically use `project-discovery` to interview you.

### After Discovery

Once you have a Project Brief:

```
Generate the project documentation
```

or specify a guideline:

```
Generate docs using lean-startup guidelines
```

### Direct Documentation (Skip Discovery)

If you already have clear requirements:

```
Create project docs for [detailed description]
```

---

## Choosing Guidelines

| Guideline | Best For | Coverage |
|-----------|----------|----------|
| `academic-msc` | M.Sc. submissions, formal projects | All 10 submission requirement sections |
| `lean-startup` | MVPs, hackathons, quick prototypes | Minimal viable documentation |

### Academic M.Sc. Covers (10 Sections):

1. **Project Documents and Planning** - PRD with all requirements, Architecture with C4 diagrams
2. **Code Documentation and Project Structure** - 150-line limit, naming conventions, docstrings
3. **Configuration Management and Security** - No secrets in code, `.env.example`
4. **Testing and Software Quality** - 70%+ coverage, edge cases, automated reports
5. **Research and Results Analysis** - Parameter studies, Jupyter notebooks, visualizations
6. **User Interface and User Experience** - Nielsen's heuristics, screenshots, workflows
7. **Version Management and Development** - 10-20+ commits, prompt engineering log
8. **Costs and Pricing** - Token usage tables, optimization strategies
9. **Extensibility and Maintainability** - Plugin architecture, extension points
10. **International Quality Standards** - ISO/IEC 25010 compliance checklist

### Lean Startup Produces:
- 1-page PRD (5 bullet points)
- ASCII box diagram
- Minimal code standards
- Now/Next/Later task list

---

## Customization

### Adding a New Guideline

1. Create `project-docs-generator/guidelines/your-guideline.md`
2. Include the meta header:
   ```yaml
   id: your-guideline
   version: 1.0
   extends: _base
   ```
3. Define requirements for each document type
4. Update SKILL.md's guideline table

### Modifying Interview Questions

Edit `project-discovery/SKILL.md` to add/remove phases or questions.

---

## Verification

Check that skills are loaded:

```
What skills are available?
```

Claude should list both `project-discovery` and `project-docs-generator`.

---

## Troubleshooting

### Skills Not Found

1. Check file location:
   ```bash
   ls ~/.claude/skills/project-discovery/SKILL.md
   ls ~/.claude/skills/project-docs-generator/SKILL.md
   ```

2. Restart Claude Code after adding skills

### Wrong Guideline Used

Specify explicitly:
```
Use the lean-startup guideline for this project
```

### Claude Skips Discovery

Be explicit:
```
Run the project discovery interview for my idea
```
